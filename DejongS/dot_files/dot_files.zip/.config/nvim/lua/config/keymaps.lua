-- Keymaps are automatically loaded on the VeryLazy event
-- Default keymaps that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/keymaps.lua
-- Add any additional keymaps here
-- vim.keymap.set('n', '<leader>h', '<C-w><Left>')
-- vim.keymap.set('n', '<leader>l', '<C-w><Right>')
vim.keymap.set("n", "<leader>q", ":q<CR>")
vim.keymap.set("n", "<leader>w", ":w<CR>")
-- vim.keymap.set("n", "<leader><CR>", ":below terminal<CR>")
